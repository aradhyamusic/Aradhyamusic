#
# Copyright (C) 2024 by THE-VIP-BOY-OP@Github, < https://gist.github.com/aradhyamusic >.
#
# This file is part of < https://gist.github.com/aradhyamusic > project,
# and is released under the MIT License.
# Please see < https://gist.github.com/aradhyamusic/blob/master/LICENSE >
#
# All rights reserved.

from .config import *
